package task_2;

public class ScrambledEggs {
	public void crackEggs(int numOfEggs2) {
		System.out.println("Cracking: " + numOfEggs2 + " eggs");
	}
	
	public void stirEggs() {
		System.out.println("Stirring and adding milk to the eggs.");
	}
	
	public void cook() {
		System.out.println("Scrambling the eggs.");
	}
	
	public void serve() {
		System.out.println("Placing the eggs on the plate.\n");
	}

}