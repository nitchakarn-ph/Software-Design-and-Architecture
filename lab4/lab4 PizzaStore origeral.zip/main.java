package lab4;

public class main {
	public static void main(String[] arg) {
	
		SimplePizzaFactory factory = new SimplePizzaFactory();
		
		PizzaStore pizzastore = new PizzaStore(factory);
		
		Pizzas pizza = pizzastore.orderPizza("cheese");
		
		System.out.println("order .. " + pizza.getName());
	
	}
}
