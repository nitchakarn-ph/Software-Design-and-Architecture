package lab4;



public class KhonkeanCheesePizza extends Pizzas {

	
	public KhonkeanCheesePizza() {
		this.setName("Khonkean Cheese Pizza");
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
