package lab4;

public class Chesses extends Pizzas {

	public Chesses() {
		this.setName("cheese");
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
