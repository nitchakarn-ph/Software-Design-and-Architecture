package lab4;

public class KhonkeanPizzaStore {

}
