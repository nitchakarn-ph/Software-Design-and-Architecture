package lab4;

public  class PizzaStore {
	protected SimplePizzaFactory factory;
	
	public PizzaStore(SimplePizzaFactory factory) {
		this.factory = factory;
	}
	
	public Pizzas orderPizza(String type) {
		Pizzas pizza = factory.createPizza(type); //Dependency
	
		
		pizza.prepare();
		pizza.bake();
		pizza.cut();
		pizza.box();
		
		
		return pizza;
	}
}
