package lab4;

public class BangkokCheesePizza extends Pizzas {

	public BangkokCheesePizza() {
		this.setName("Bangkok Cheese Pizza");
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

}
