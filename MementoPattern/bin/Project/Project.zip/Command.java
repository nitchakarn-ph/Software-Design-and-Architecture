package Project;

public abstract class  Command {
	
	public abstract void excute(Inventory newInvent);
}
