package BookStore;

@SuppressWarnings("serial")
public class MatchNotFoundException extends Exception {
	public MatchNotFoundException(String s){
		super(s);
	}
}
