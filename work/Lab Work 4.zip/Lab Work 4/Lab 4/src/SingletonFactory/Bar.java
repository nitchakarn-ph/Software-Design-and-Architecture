package SingletonFactory;

public abstract class Bar {
	public int id;
}