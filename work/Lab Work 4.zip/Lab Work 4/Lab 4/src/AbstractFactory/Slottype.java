package AbstractFactory;

public enum Slottype {
    progressive, straight, bonus 
}
