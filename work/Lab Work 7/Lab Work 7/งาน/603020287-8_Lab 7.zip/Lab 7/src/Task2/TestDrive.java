package Task2;

public class TestDrive {
	public static void main(String[] args) {
		RemoteDeviceV1 remote = new RemoteDeviceV1();
		remote.pressPlay();
		remote.pressPause();
		remote.pressStop();
		remote.pressPlay();
		remote.pressPlay();

	}

}
