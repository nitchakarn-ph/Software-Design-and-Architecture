package Adapter;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		Employee client = new Employee();
		client.request();
	}
	
}
