
public class Main {

	public static void main(String[] args) {
		 Baby b = new Baby("Paw");
		 b.setData(true, 10);
		 Baby c = new Baby("Mee");
		 
		 Observer o  = new BabyMonitorSimple("Home",b);
		 
		 b.registerObserver(new BabyMonitorSimple("Home",b));
		 b.registerObserver(new BabyMonitorAdvanced("Home",b,c));
		 
	}

}
