package BookStores;

@SuppressWarnings("serial")
public class MatchNotFoundException extends Exception {

	MatchNotFoundException(String s){
		super(s);
	}
}
