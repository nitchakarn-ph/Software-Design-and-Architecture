package Task1;

public abstract class DrawingService {
	public abstract void drawLine(int x1, int y1, int x2, int y2);
	public abstract void drawCircle(int x, int y, int r);
}
