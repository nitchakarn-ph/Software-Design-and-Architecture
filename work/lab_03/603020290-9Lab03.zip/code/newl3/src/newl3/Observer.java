package newl3;

public interface Observer {
	public void update(String babyname, boolean crying, int level);
}
