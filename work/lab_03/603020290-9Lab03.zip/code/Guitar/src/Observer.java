
public interface Observer {
	public void update(String cname, String gtname,String action);
}
