
public interface Iterator {

	
	public Object next();
	boolean hasNext();
}
