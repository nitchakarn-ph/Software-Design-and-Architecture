package task_1;

public interface Command {
	public void undo();
	public void redo();
}