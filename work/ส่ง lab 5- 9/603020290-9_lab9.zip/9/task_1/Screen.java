package task_1;

public interface Screen {
	public void draw_line(int x1, int y1, int x2, int y2);
	public void draw_pixel(int x,int y);
	public void draw_circle(int x,int y,int r);
}
