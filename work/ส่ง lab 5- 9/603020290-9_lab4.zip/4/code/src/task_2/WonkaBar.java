package task_2;

public class WonkaBar extends Bar {

	public WonkaBar(int identifier) {
		id = identifier;
	}	
}