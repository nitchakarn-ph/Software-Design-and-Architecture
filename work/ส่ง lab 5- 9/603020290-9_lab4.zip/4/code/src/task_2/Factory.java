package task_2;

public interface Factory {
	 Bar create(int id);
}
