package task_2;

public abstract class Bar {
	public int id;
}