package task_1;

public enum Slottype {
    progressive, straight, bonus 
}
