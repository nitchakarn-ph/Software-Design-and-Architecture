package task_1;

public class NVSlotProgressive extends Slot {
	
	public NVSlotProgressive() {
		cost = 300;
		name = "Progressive";
		software = "Android";
		
		components.add("Large");
		components.add("Ticketinticketout");
		components.add("LCD");
		components.add("X77");
	}
}
