
public class DarkRost extends Beverage {

	public DarkRost() {
		this.descrition = "Dark Rost";
	}
	 public double cost() {
		 return 0.99;
	 }
}
