
public abstract class Beverage {
	protected String descrition = "Unknown Beverage";
	
	public String getDescripting() {
		return descrition;
	}
	public abstract double cost();
	
}
