
public class Decaf extends Beverage {

	 public double cost() {
		 return 1.05;
	 }
}
