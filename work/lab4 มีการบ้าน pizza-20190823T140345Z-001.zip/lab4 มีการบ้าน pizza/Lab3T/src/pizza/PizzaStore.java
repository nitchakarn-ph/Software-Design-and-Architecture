package pizza;

public class PizzaStore {
	
	/*SimplePizzaFactory factory;
	
	protected  Pizza createPizza(String type) {
		Pizza pizza = null;
		if(type.equals("chesses")) {
			pizza = new ChessesPizza();
		}
	}*/
	
}
