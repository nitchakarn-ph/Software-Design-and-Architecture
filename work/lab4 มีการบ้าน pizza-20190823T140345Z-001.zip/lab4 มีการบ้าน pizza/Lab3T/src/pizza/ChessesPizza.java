package pizza;

public class ChessesPizza {

	public ChessesPizza() {
		
	}
}
