package Template;

public class SunnySide {
	public void crackEggs(int numOfEggs3) {
		System.out.println("Cracking: " + numOfEggs3 + " eggs.");
	}
	
	public void prepare() {
		System.out.println("Never stir sunny side up!");
	}
	
	public void cook() {
		System.out.println("Cooking the eggs sunny side up.");
	}
	
	public void serve() {
		System.out.println("Placing the eggs on a plate.\n");
	}

}
