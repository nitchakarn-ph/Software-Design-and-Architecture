package Facade;

public class Tea {
	private String flavor;
	
	public Tea(String flavor) {
		this.flavor = flavor;
	}
	
	public String getflavor() {
		return flavor;
	}

}