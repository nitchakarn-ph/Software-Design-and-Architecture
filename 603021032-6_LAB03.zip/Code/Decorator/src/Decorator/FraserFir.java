package Decorator;

public class FraserFir extends Tree{
	public FraserFir() {
		description = "FraserFir";
	}
	public double cost() {
		return 12.00;
	}
}
