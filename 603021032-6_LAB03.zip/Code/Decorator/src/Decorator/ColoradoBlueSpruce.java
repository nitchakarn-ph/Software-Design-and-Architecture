package Decorator;

public class ColoradoBlueSpruce extends Tree {
		public ColoradoBlueSpruce() {
			description = "Colorado Blue Spruce tree decorated with";
		}
		public double cost() {
			return 20.00;
		}
}
