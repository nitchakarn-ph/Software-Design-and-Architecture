package Decorator;

public class BalsamFir extends Tree {
	public BalsamFir() {
		description = "Balsam Fir";
	}
	public double cost() {
		return 5.00;
	}
}
