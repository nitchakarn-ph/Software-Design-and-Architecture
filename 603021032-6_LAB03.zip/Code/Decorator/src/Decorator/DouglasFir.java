
package Decorator;

public class DouglasFir extends Tree{
	public DouglasFir() {
		description = "Douglas Fir";
	}
	public double cost() {
		return 15.00;
	}
}
