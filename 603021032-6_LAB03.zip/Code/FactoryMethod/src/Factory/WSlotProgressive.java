package Factory;

public class WSlotProgressive extends Slot{
	public WSlotProgressive() {
		name="Progressive";
		software = "Android";
		components.add("Large");
		components.add("coins");
		components.add("reels");		
		components.add("ARM");
	}
}
