package Factory;

public class WSlotBonus extends Slot{
	public WSlotBonus() {
		name="Bonus";
		software = "Symbian";
		components.add("Medium");
		components.add("ticketinticketout");
		components.add("VGA");
		components.add("ARM");
	}
}
