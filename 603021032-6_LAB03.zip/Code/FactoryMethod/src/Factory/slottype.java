package Factory;

public enum slottype {
    progressive, straight, bonus 
}
