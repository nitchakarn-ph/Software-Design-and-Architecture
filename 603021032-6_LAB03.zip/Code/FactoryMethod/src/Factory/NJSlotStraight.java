package Factory;

public class NJSlotStraight extends Slot {
	public NJSlotStraight() {
		name="Straight";
		software = "Windows ME";
		components.add("Small");
		components.add("coins");
		components.add("LCD");
		components.add("ARM");
	}
}
