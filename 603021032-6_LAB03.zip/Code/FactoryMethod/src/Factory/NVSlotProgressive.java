package Factory;

public class NVSlotProgressive extends Slot {
	
	public NVSlotProgressive() {
		name="Progressive";
		software = "Android";
		components.add("Medium");
		components.add("Ticketinticketout");
		components.add("LCD");
		components.add("X77");
	}
}
