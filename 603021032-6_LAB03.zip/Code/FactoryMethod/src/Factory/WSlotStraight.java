package Factory;

public class WSlotStraight extends Slot{
	public WSlotStraight() {
		name="Straight";
		software = "Linux";
		components.add("Large");
		components.add("bills");
		components.add("reels");
		components.add("ARM");
	}
}
