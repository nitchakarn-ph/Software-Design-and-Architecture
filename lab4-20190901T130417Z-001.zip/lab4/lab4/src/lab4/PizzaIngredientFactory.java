package lab4;

public interface PizzaIngredientFactory {
	public Cheese createCheese(String type);
}
