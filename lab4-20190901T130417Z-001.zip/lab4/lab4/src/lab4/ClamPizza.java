package lab4;

public class ClamPizza extends Pizzas {

	public ClamPizza() {
		this.setName("clam pizza");
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
}
