package lab4;

public class MozzalaCheese implements Cheese {

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	
}
