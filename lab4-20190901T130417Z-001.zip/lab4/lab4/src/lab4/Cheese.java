package lab4;

public interface Cheese {

	public String toString();
}
