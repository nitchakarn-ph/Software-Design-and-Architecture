package lab8_iteratorPattern;

public interface Menu {
	Iterator createIterator();
}
